#!/bin/bash
cp -f ./60-udev-robotcoding.rules /etc/udev/rules.d/
